/* Eulerian Analytics #41244195 */
var mypublisher = window.mypublisher = '';
var myvia = window.myvia = '';
var mymedia = window.mymedia = '';
var myope = window.myope = '';
var mydate = window.mydate = '';
var mycreative = window.mycreative = '';

