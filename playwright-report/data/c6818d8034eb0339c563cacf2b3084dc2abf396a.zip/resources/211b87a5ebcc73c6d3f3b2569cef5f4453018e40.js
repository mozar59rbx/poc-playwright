/* #1634297577 */
(function(o){
o.pmtcrec 	= 0;o.rcollector = function(a) {var o = _oEa;o.pmtcrec = 1;o.recurse(1);o.collector( a );};o.pmdenyall = 0;o.tcfv2dh	= 224807530;o.tcfv2cvh	= 1600468151;o.pmtcfv2thaw = function() {var h, o = _oEa, d = o.tcfv2d, cv, t, wcv = 0;var amisc = [];var cvmap = {"realytics" : "2459","bing" : "10003","next performance" : "10008","tradedoubler ab" : "486","facebook" : "89","ecselis" : "10004","kenshoo" : "10007","goracash" : "10001","atlas" : "10009","tradelab" : "10006","at internet" : "587","microsoft" : "326","Strikehead" : "10010","exelate" : "10005","LeBonCoin" : "10002","tobemogul" : "10011"};o.hpmvendor = o.hpmpurpose = o.hpmsfeature = {};o.hpmcustomvendor = {};cv = o.tcfv2cv = [];if (cvmap) {/* Specifics *//* didomi */t = window.didomiState;if (o.isdef( typeof t ) && o.isdef( typeof t.didomiVendorsConsent )){t.didomiVendorsConsent.split(',').forEach(function(k) {if (k.substr(0,4)!=="iab:") {cv.push( k.substr(k.indexOf(':')+1) ) } } );wcv = 1;}/* onetrust */}/* with __eaGenericCmpApi */if (d && d.eamode === 'tac' && (t = d.eapayload) && t.state) {var k;for(k in t.state){ /* at least one state defined */d.tcString=d.tcString||'CPjTJ1aPjTJ1aOhAAAENCZCgAAAAAAAAAAAAAAAAAAAA.YAAAAAAAAAA';if(t.state[k]){cv.push( k + '-tac' ); wcv = 1;if (k === 'eulerian' || k === 'eulerian-analytics'){d.tcString='CPjTJ1aPjTJ1aOhAAAENCZCgAAAAAAAAAAAADOwAQDOgAAAA.YAAAAAAAAAA';}} }}if (d && o.isdef(d.tcString)) {h = o.h31(d.tcString);if (h !== o.tcfv2dh) {amisc.push('gdpr_consent', d.tcString, 'pmact', ((o.tcfv2dh)?'tcfrefresh':'tcfnew'));o.tcfv2dh = h;}if (d.vendor) { o.hpmvendor = d.vendor.consents||{}; }if (d.purpose) { o.hpmpurpose = d.purpose.consents||{}; }o.hpmsfeature = d.specialFeatureOptins||{};if (d.hasOwnProperty( "addtlConsent" )) {var s = d.addtlConsent;wcv = 1;if (o.isdef(s)) {cv.push.apply(cv,s.substr(s.indexOf('~')+1).split('.')); }}}if (wcv) {var acvid=[],cvid={},cvids,k,pv=0,tk,nk;cv.forEach(function(k) {if (cvmap[k]) { k = cvmap[k]; }else if ((tk = k.lastIndexOf('-'))>0) {if ((nk = cvmap[k.substr(0,tk)])) { k = nk; }}if (parseInt(Number(k)) == k) { cvid[ k ]=1; o.hpmcustomvendor[ k ] = 1; }});for (k in cvid) { acvid.push(k); }cvid=acvid.sort(function(a,b){return a-b;}); acvid=[];cvid.forEach(function(k){if(k-pv){acvid.push(k-pv);pv=k;}});cvids = acvid.join('.')||'-';h = o.h31(cvids);if (h !== o.tcfv2cvh) {amisc.push('gdpr_customvendor', cvids);o.tcfv2cvh = h;}}if (amisc.length) {o.misc('', amisc );o._mtdcrun();}};o.hpmdeny = o.hpmdeny || {};o.aInH = function(a,h) {var i=0;if (!_oEa.isobj(a)) { if (a === '*') { return 1; } a = a.split('-'); }while (i<a.length) { if (! h[ a[i++] ]) { return 0; } }return 1;};o.pmpass = function( pmcat, tcfv2vendor, tcfv2purpose, tcfv2customvendor, tcfv2sfeature ) {var o = _oEa;if (tcfv2purpose && o.aInH( tcfv2purpose, o.hpmpurpose ) &&((tcfv2vendor && o.aInH( tcfv2vendor, o.hpmvendor ))||(tcfv2customvendor && o.aInH( tcfv2customvendor, o.hpmcustomvendor ))) &&(! tcfv2sfeature || o.aInH( tcfv2sfeature, o.hpmsfeature ))) { return 1; }return 0;};
o.website("sofinco");if (o.isdef(typeof o.uidset )) {o.uidset("5J7FzGjGD2KAxllV61_LUhfQe999Sz3Bl2TIGD3W_7cRfuT2Gc_YWw--");}var _EaCP = {"cgip" : o.hcgi,"tp":{"":""}};o.jsbwr = {'s'   : '//mcc1.sofinco.fr/w.js', /* DomWrite */'pre' : function(){ _oEaDWR.capture(); },'post': function(){ _oEaDWR.render(_oEa.b); }};if (typeof o.gloadtimeout !== 'function') {o.gloadtimeout = function( to, id, tg ) {};}o['_adcrun']=[]; o['_adcrunNC']=[]; o.dcids={};o.xpathdc={};o['_amtrun']=[]; o['_amtrunNC']=[]; o.mtids={};o.xpathmt={};o._arunpush = function(x,f) { _oEa[x].push(f); };o._arunpush2 = function(x,f) { _oEa._arunpush(x,f);_oEa._arunpush(x+'NC',f); };o._arun = function(x,p) { _oEa[x].forEach(function(f){f(p);}); };o.mtrun = function(nc) { _oEa._arun( '_amtrun'+((nc)?'NC':''), nc ); };o.dcrun = function(nc) { _oEa._arun( '_adcrun'+((nc)?'NC':''), nc ); };o._mtdcrun = function() {clearTimeout( _oEa._mtdcrunto );_oEa._mtdcrunto = setTimeout(function(){_oEa.mtrun();_oEa.dcrun();}, 50 );};
o._arunpush2('_adcrun',function( nc ) { /* nc: no consent */
var o = _oEa;
if (!nc && o.pmdenyall) { return; }
});
o._arunpush2('_amtrun',function( nc ) {
var o = _oEa;
o.xpathmt = o.xpathmt || {};
o.mtids = o.mtids || {};
if (o.pmdenyall) { return; }
if (! o.mtids["262"]) {
/* {ccmt:244,ccmth:262,isimg,view:0,hdlr:tag,mtpmcat:,ccmtn:Facebook - visiteurs} */
if ( !nc && o.pmpass('',
 '','1-3-4-7',
 '89',''
) )
{
o.mtids["262"]="pmpass";
try{
/* Img */
  o.gloadtimeout(
   5000,
   "DEQwyRwgEDJm_8YpRfhhLi1_.mkrjFRrOGvjlUFl",
  o.gloadimg("https://www.facebook.com/tr?id=1565689703652872&ev=Visiteurs&noscript=1")
 )
;
 /* /mtjs */
}catch(e){if (o.logsend){o.logsend('mt','244',e);}else{o.log('mt',e);}}
}
}
if (! o.mtids["523"]) {
/* {ccmt:505,ccmth:523,isnative,view:5,hdlr:tag,mtpmcat:,ccmtn:Bing remarketing} */
if ( !nc && o.pmpass('',
 '','1-3-4-7',
 '326',''
) )
{
o.mtids["523"]="pmpass";
try{
/* Native */
/*global UET */_oEa.gloadtimeout(5000, "DEQwyRwgEDJm_8YpRfj94Fj239iKrQ_60ow7uqN0",_oEa.gloadjs("https://bat.bing.com/bat.js", function(){var uetq = window.uetq = window.uetq || [];var _buetq_obj = {ti:"5140115"};_buetq_obj.q = window.uetq;window.uetq = new UET(_buetq_obj);window.uetq.push("pageLoad");window.uetq.push({});}));
 /* /mtjs */
}catch(e){if (o.logsend){o.logsend('mt','505',e);}else{o.log('mt',e);}}
}
}
if (! o.mtids["1819"]) {
/* {ccmt:1648,ccmth:1819,isjs,view:5,hdlr:tag,mtpmcat:,ccmtn:DCM - Landing Pages - version JS} */
if ( !nc && o.pmpass('',
 '755','1-3-4-7',
 '',''
) )
{
o.mtids["1819"]="pmpass";
try{
/* JS */
 /* !mtembedjs */
 o.gloadtimeout(
  5000,
  "8lL.QlYVeQ7BL6AqQORYbiaDT1DVFiS5wk31PNPJBg--",
o.gloadjssrc("","var rdmDBI = Math.random() * 10000000000000;\n"+
"var scriptDBI = document.createElement(\"script\");\n"+
"scriptDBI.type = \"text/javascript\";\n"+
"scriptDBI.src = \"https://6549210.fls.doubleclick.net/activityj;src=6549210;type=sofinco;cat=landings;u1=https://mon-espace-client.sofinco.fr/ancienne-authent/identifiant-oublie/contacts-invalides;dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=\"+rdmDBI;\n"+
"document.getElementsByTagName(\"script\")[0].parentNode.appendChild(scriptDBI);\n"+
"","","tag 1648/1819")
);
 /* /!mtembedjs */
 /* /mtjs */
}catch(e){if (o.logsend){o.logsend('mt','1648',e);}else{o.log('mt',e);}}
}
}
if (! o.mtids["2107"]) {
/* {ccmt:1927,ccmth:2107,isjs,view:0,hdlr:tag,mtpmcat:,ccmtn:Havas - Tag container} */
if ( !nc && o.pmpass('',
 '755','1-3-4-7',
 '',''
) )
{
o.mtids["2107"]="pmpass";
try{
/* JS */
 /* !mtembedjs */
 o.gloadtimeout(
  5000,
  "8lL.QlYVeQ7BL6AqQORYVQdrrTs1IDjgwzOYnr4fow--",
o.gloadjssrc("","window.dataLayer = window.dataLayer || [];\n"+
"\n"+
"  function gtag()\n"+
"{\n"+
"  dataLayer.push(arguments);\n"+
"}\n"+
"\n"+
"  gtag('js', new Date());\n"+
"\n"+
"  gtag('config', 'DC-6549210');","","tag 1927/2107")
);
 /* /!mtembedjs */
 /* /mtjs */
}catch(e){if (o.logsend){o.logsend('mt','1927',e);}else{o.log('mt',e);}}
}
}
if (! o.mtids["3376"]) {
/* {ccmt:3043,ccmth:3376,isjs,view:0,hdlr:tag,mtpmcat:,ccmtn:Numberly - Realytics} */
if ( !nc && o.pmpass('',
 '1025','2-3-4-5-6-7-8',
 '',''
) )
{
o.mtids["3376"]="pmpass";
try{
/* JS */
 /* !mtembedjs */
 o.gloadtimeout(
  5000,
  "8lL.QlYVeQ7BL6AqQORYt_.PtgEf2UHRDnkTVyOg8Q--",
o.gloadjssrc("","window.RY=(function(e){var t=[\"identify\",\"track\",\"trackLink\",\"trackForm\",\"transaction\",\"page\",\"profile\",\"sync\",\"consent\",\"reject\"];var n=\"realytics\";var r=function(e){return!!(e&&(typeof e==\"function\"||typeof e==\"object\"))};var i=function(e,t){return function(){var n=Array.prototype.slice.call(arguments);if(!e[t])e[t]=[];e[t].push(n?n:[]);if(!e[\"_q\"])e[\"_q\"]=[];e[\"_q\"].push(t)}};var s=function(r){for(var s=0;s < t.length;s++){var o=t[s];if(r)e[r][o]=i(e._q[r],o);else e[o]=e[n][o]=i(e._q[n],o)}};var o=function(t,r,i){var o=t?t:n;if(!e[o])e[o]={};if(!e._q[o])e._q[o]={};if(r)e._q[o][\"init\"]=[[r,i?i:null]];s(t)};if(!e._v){if(!e._q){e._q={};o(null,null,null)}e.init=function(e,n){var i=n?r(n)?n[\"name\"]?n[\"name\"]:null:n:null;if(i&&t)for(var s=0;s < t.length;s++)if(i==t[s]||i==\"init\")return;o(i,e,r(n)?n:null);var u=function(e){var t=document.createElement(\"script\");t.type=\"text/javascript\";t.async=true;t.src=(\"https:\"==document.location.protocol?\"https://\":\"http://\")+e;var n=document.getElementsByTagName(\"script\")[0];n.parentNode.insertBefore(t,n)};u(\"i.realytics.io/tc.js?cb=\"+(new Date).getTime());u(\"cdn-eu.realytics.net/realytics-1.2.min.js\")}}return e})(window.RY||{});RY.init(\"ry-dat41fap\");RY.page();","","tag 3043/3376")
);
 /* /!mtembedjs */
 /* /mtjs */
}catch(e){if (o.logsend){o.logsend('mt','3043',e);}else{o.log('mt',e);}}
}
}
if (! o.mtids["3169"]) {
/* {ccmt:2863,ccmth:3169,isjs,view:5,hdlr:tag,mtpmcat:,ccmtn:Floodlight Havas 2020 - Global site tag - DC-6549210} */
if ( !nc && o.pmpass('',
 '755','1-3-4-7',
 '10003',''
) )
{
o.mtids["3169"]="pmpass";
try{
/* JS */
 /* !mtembedjs */
 o.gloadtimeout(
  5000,
  "8lL.QlYVeQ7BL6AqQORYQrIofCCHLW34kO6.iNDUdA--",
o.gloadjssrc("https://www.googletagmanager.com/gtag/js?id=DC-6549210","window.dataLayer = window.dataLayer || [];\n"+
"function gtag()\n"+
"{\n"+
"  dataLayer.push(arguments);\n"+
"}\n"+
"\n"+
"gtag('js', new Date());\n"+
"gtag('config', 'DC-6549210');\n"+
"","","tag 2863/3169")
);
 /* /!mtembedjs */
 /* /mtjs */
}catch(e){if (o.logsend){o.logsend('mt','2863',e);}else{o.log('mt',e);}}
}
}
if (! o.mtids["3340"]) {
/* {ccmt:2611,ccmth:3340,isnative,view:0,hdlr:tag,mtpmcat:,ccmtn:Numberly - v1} */
if ( !nc && o.pmpass('',
 '388','1-3-4-5-6-7-8-10',
 '',''
) )
{
o.mtids["3340"]="pmpass";
try{
/* Native */
(function(d,e,a){if (! window._troq) {window._troq = a = d._troq = function(){return (a.callTro)?a.callTro.apply(a,arguments):a.queue.push(arguments);};a.push=a;a.queue=[];a.version="1.0";}}(window,document));_troq('session_ttl', 1800 );_troq('init' , '6544093-33a554660ec13358d3e90c562221596c' );_oEa.gloadjs("//mm.eulerian.net/info/sofinco/?mymedia={media}&mypublisher={publisher}&myope={ope}&mycreative={creative}&mydate={date}&myvia={via}&eviews=5",function(){_troq('tag', {rtglvl0_chan: window.mymedia,rtglvl0_p1: window.mypublisher,rtglvl0_p2: window.myope,rtglvl0_p3: window.mycreative,rtglvl0_date: window.mydate,rtglvl0_type: window.myvia,'rtgidmarque':'','rtgidproduit':'','rtgstatutcontrat':'','rtgpg':'reconnaissance-client','rtgpagename':'','rtgclientid':'','rtgcustomer':'','rtgidcat':'','rtgidsubcat':'','rtgstep':'','rtglogged':'0','rtgref':'','rtgtypecontrat':'','rtgnbdevis':'','rtgnbcontracts':'','rtgtype':'','rtgmontant_disponible':'','rtgdepenses_credit':'','rtgcarte':'','rtgamount':'','rtganciennemensualite':'','rtgnouvellemensualite':'','rtgtyperepartition':'','rtgmontantmensualite':'','rtgmontant_retard':'','rtgmontant':'','rtgtaeg':'','rtgtauxdeb':'','rtgsimulation':'','rtgancienmontant':'','rtgnouveaumontant':'','rtgnbmensualite':'','rtgmensualite':'','rtgdernieremensualite':'','rtgoptioneconsentement':'','rtgiddos':'','rtgsite':'sofandco','rtgtypeoffre':'','rtgidperso_edito':'','rtgidperso_encarts':'','rtgidperso_carrousel':'','rtgtypeproduit':'','rtgemprunteur':'','rtgmontantacredit':'','rtgchoixmodalites':'','rtgtypecarte':'','rtgenvoi':'','rtgtypesignature':'','rtganciennedate':'','rtgnouvelledate':'','rtgmontantutilise':'','rtgnouveaumontantmensualite':'','rtgprovenance':'','rtgnomproduit':'','rtgmotifresiliation':'','rtgsousmotif':'','rtgprojet':'','rtgmotif':'','rtgmoyen':'','rtgnomparcours':'','rtgfirsttime':'','rtgmoyenverif':'','rtgnumessai':'','rtgpageorigine':''});});_oEa.gloadjs("https://mmtro.com/tro.js");
 /* /mtjs */
}catch(e){if (o.logsend){o.logsend('mt','2611',e);}else{o.log('mt',e);}}
}
}
});
o.waitPM = function(f) {var o = _oEa;if (! o.tcfv2d) {setTimeout( f, 100 );return 1;}o.pmtcfv2thaw();return 0;};o.tcfv2load();o.mtdcrun = function() {var o = _oEa;if (o.waitPM( o.mtdcrun )) { return; }o._mtdcrun();};o.mtdcrunNC = function() {var o = _oEa;o.dcrun(1);o.mtrun(1);};o.mtdcrunNC();o.mtdcrun();o.websiteend();
})(_oEa);
